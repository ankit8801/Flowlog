/**
 * background.js — Service Worker (v2 fixed)
 *
 * KEY FIXES:
 * 1. Focus state synced to chrome.storage.local — content script reads it on load
 *    without needing message passing (eliminates race condition)
 * 2. Sessions stored with error logging (was silent catch)
 * 3. Sensitivity thresholds fixed: high=always, medium=first visit, low=after grace period
 * 4. DB upgrade is idempotent — safe to run even if stores already exist
 */

importScripts("categories.js");

// ─── Constants ────────────────────────────────────────────────────────────────
const DB_NAME    = "focus_tracker_db";
const DB_VERSION = 2;
const MIN_SESSION_SECONDS = 0;

// ─── State ────────────────────────────────────────────────────────────────────
let currentSession = null;

// ─── IndexedDB ────────────────────────────────────────────────────────────────
function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = (e) => {
      const db  = e.target.result;
      const old = e.oldVersion;

      if (old < 1) {
        if (!db.objectStoreNames.contains("activity_log")) {
          const log = db.createObjectStore("activity_log", { keyPath: "id", autoIncrement: true });
          log.createIndex("timestamp", "timestamp");
          log.createIndex("site", "site");
          log.createIndex("category", "category");
        }
      }
      if (old < 2) {
        if (!db.objectStoreNames.contains("sessions")) {
          const s = db.createObjectStore("sessions", { keyPath: "id", autoIncrement: true });
          s.createIndex("startTime", "startTime");
          s.createIndex("site", "site");
        }
        if (!db.objectStoreNames.contains("focus_events")) {
          const fe = db.createObjectStore("focus_events", { keyPath: "id", autoIncrement: true });
          fe.createIndex("type", "type");
          fe.createIndex("timestamp", "timestamp");
        }
        if (!db.objectStoreNames.contains("settings")) {
          db.createObjectStore("settings", { keyPath: "key" });
        }
        if (!db.objectStoreNames.contains("user_labels")) {
          db.createObjectStore("user_labels", { keyPath: "site" });
        }
      }
    };

    req.onsuccess = () => resolve(req.result);
    req.onerror   = (e) => {
      console.error("[FocusTracker] DB open error:", e.target.error);
      reject(req.error);
    };
  });
}

async function dbGet(store, key) {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const req = db.transaction(store, "readonly").objectStore(store).get(key);
      req.onsuccess = () => { db.close(); resolve(req.result); };
      req.onerror   = () => { db.close(); reject(req.error); };
    });
  } catch (e) {
    console.error("[FocusTracker] dbGet error:", store, key, e);
    return null;
  }
}

async function dbPut(store, data) {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const t = db.transaction(store, "readwrite");
      t.objectStore(store).put(data);
      t.oncomplete = () => { db.close(); resolve(); };
      t.onerror    = (e) => { db.close(); console.error("[FocusTracker] dbPut error:", store, e.target.error); reject(t.error); };
    });
  } catch (e) {
    console.error("[FocusTracker] dbPut outer error:", store, e);
  }
}

async function dbAdd(store, data) {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const t = db.transaction(store, "readwrite");
      const req = t.objectStore(store).add(data);
      t.oncomplete = () => { db.close(); resolve(req.result); };
      t.onerror    = (e) => { db.close(); console.error("[FocusTracker] dbAdd error:", store, e.target.error); reject(t.error); };
    });
  } catch (e) {
    console.error("[FocusTracker] dbAdd outer error:", store, e);
    return null;
  }
}

// ─── Settings ─────────────────────────────────────────────────────────────────
// chrome.storage.local IS the single source of truth for focus settings.
// The dashboard writes here via bridge.js. Background reads from here.

function getSetting(key, def = null) {
  return new Promise((resolve) => {
    chrome.storage.local.get([key], (result) => {
      resolve(result[key] !== undefined ? result[key] : def);
    });
  });
}

function setSetting(key, value) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [key]: value }, resolve);
  });
}

// ─── Dashboard Queue ──────────────────────────────────────────────────────────
// Appends data to chrome.storage.local queues that bridge.js drains on
// the dashboard page (localhost:3000).
// Sessions are relayed here because the extension's IndexedDB is a different
// origin from the dashboard page — the only cross-origin path is postMessage.
async function queueForDashboard(session, logEntry) {
  try {
    await new Promise((resolve) => {
      chrome.storage.local.get(["pendingSessions", "pendingLogs"], (result) => {
        const sessions = result.pendingSessions || [];
        const logs     = result.pendingLogs     || [];
        if (session)  sessions.push(session);
        if (logEntry) logs.push(logEntry);
        chrome.storage.local.set({ pendingSessions: sessions, pendingLogs: logs }, resolve);
      });
    });
  } catch (e) {
    console.error("[FocusTracker] queueForDashboard error:", e);
  }
}

// ─── User labels ──────────────────────────────────────────────────────────────

async function getUserLabel(site) {
  const rec = await dbGet("user_labels", site);
  return rec ? rec.label : null;
}

// ─── Hybrid Classifier ────────────────────────────────────────────────────────

function analyzeBehavior(session) {
  const { duration, tabSwitches, interactions } = session;

  // Long focused session → productive
  if (duration >= 1800 && tabSwitches <= 3 && interactions >= 20) {
    return { category: "productive", reason: "behavior_heuristic", confidence: "medium" };
  }

  // Restless long session → distracting
  if (duration >= 1200 && tabSwitches >= 7) {
    return { category: "distracting", reason: "behavior_heuristic", confidence: "medium" };
  }

  return null;
}

async function classifySession(session) {
  // Layer 1: User override
  const userLabel = await getUserLabel(session.site);
  if (userLabel) {
    return { category: userLabel, reason: "user_override", confidence: "high" };
  }

  // Layer 2: Behavior signals
  const behaviorResult = analyzeBehavior(session);
  if (behaviorResult) return behaviorResult;

  // Layer 3: Default category map
  const [blockedDomains, productiveDomains] = await Promise.all([
    getSetting("blockedSites", []),
    getSetting("productiveDomains", [])
  ]);
  const cat = resolveCategory(session.site, { blockedDomains, productiveDomains });
  return { category: cat, reason: "default_list", confidence: "low" };
}

// ─── Session Builder ──────────────────────────────────────────────────────────

function getHostname(url) {
  try { return new URL(url).hostname.replace(/^www\./, ""); }
  catch { return null; }
}

async function endCurrentSession() {
  if (!currentSession) return;

  const endTime  = Date.now();
  const duration = Math.round((endTime - currentSession.startTime) / 1000);

  if (duration < MIN_SESSION_SECONDS) { currentSession = null; return; }

  const classification = await classifySession(currentSession); // Need to use session.site, wait, we built a temp session. Let's rebuild properly.

  const finalCategory = classification.category;

  const sessionObj = {
    id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(),
    type: "background",
    domain: currentSession.site,
    title: "",
    startTime: new Date(currentSession.startTime).toISOString(),
    endTime: new Date(endTime).toISOString(),
    durationMs: duration * 1000,
    category: finalCategory,
    sessionGroup: new Date(currentSession.startTime).toISOString().split('T')[0]
  };
  
  console.log("[FocusTracker] Session ended:", sessionObj.domain, sessionObj.durationMs + "ms", sessionObj.category);

  // Store in sessions securely
  const sid = await dbAdd("sessions", sessionObj);
  console.log("[FocusTracker] Session stored, id:", sid);

  // Also write activity_log for dashboard analytics
  const logEntry = {
    site:      currentSession.site,
    duration:  duration,
    timestamp: new Date(currentSession.startTime).toISOString(),
    category:  finalCategory,
    confidence: classification.confidence,
    reason:    classification.reason,
    source:    "extension",
  };
  await dbAdd("activity_log", logEntry);

  // Queue session AND logEntry for the bridge to relay to the dashboard.
  // Sessions must travel via postMessage because extension IndexedDB is
  // a different origin from the dashboard page at localhost:3000.
  await queueForDashboard(sessionObj, logEntry);

  currentSession = null;
}

async function startNewSession(url) {
  await endCurrentSession();

  let site = 'unknown';
  if (url && url !== 'undefined') {
    try {
      site = new URL(url).hostname.replace(/^www\./, "");
    } catch {
      site = 'unknown';
    }
  }

  if (
    !site || 
    site === 'unknown' || 
    site === 'undefined' || 
    site === 'localhost' || 
    site.startsWith('localhost:') || 
    site === '127.0.0.1' || 
    (url && (url.startsWith("chrome://") || url.startsWith("chrome-extension://")))
  ) {
    return;
  }

  currentSession = {
    url,
    site,
    startTime:    Date.now(),
    interactions: 0,
    tabSwitches:  0,
  };

  console.log("[FocusTracker] Session started:", site);
}

// ─── Focus Mode Controller ────────────────────────────────────────────────────

async function checkFocusMode(site, tabId) {
  const focusEnabled = await getSetting("focusEnabled", false);
  if (!focusEnabled) return;

  const [blockedSites, productiveDomains, sensitivity, allowContinue, sessionStart, sessionDuration] =
    await Promise.all([
      getSetting("blockedSites",    []),
      getSetting("productiveDomains", []),
      getSetting("sensitivity",     "medium"),
      getSetting("allowContinue",   true),
      getSetting("sessionStart",    null),
      getSetting("sessionDuration", 25),
    ]);

  // Check session time limit
  if (sessionDuration && sessionStart) {
    const elapsed = (Date.now() - new Date(sessionStart).getTime()) / 60000;
    if (elapsed >= sessionDuration) {
      console.log("[FocusTracker] Session time limit reached");
      await setSetting("focusEnabled", false);
      await setSetting("sessionStart", null);
      await logFocusEvent("session_ended_time_limit", site);
      sendToTab(tabId, { type: "FOCUS_ENDED", reason: "time_limit" });
      return;
    }
  }

  // Check blocked
  const blocked = Array.isArray(blockedSites) ? blockedSites : [];
  const isBlocked = blocked.some(d => site === d || site.endsWith("." + d));
  if (isBlocked) {
    console.log("[FocusTracker] Blocked site:", site);
    await logFocusEvent("site_blocked", site);
    sendToTab(tabId, { type: "SHOW_BLOCK", site, allowContinue });
    return;
  }

  // Check category
  const userLabel = await getUserLabel(site);
  const category  = userLabel || resolveCategory(site, { blockedDomains: blockedSites, productiveDomains });
  if (category === "productive") return;
  if (category !== "distracting") return;

  // Sensitivity: 'low' = warn after 5min on site, 'medium' = warn on enter, 'high' = warn on enter
  // (actual per-page toast is handled by content.js on load;
  //  this path handles MID-SESSION switches that content.js won't catch)
  console.log("[FocusTracker] Distracting site in focus mode:", site, "sensitivity:", sensitivity);
  await logFocusEvent("warning_shown", site);
  sendToTab(tabId, { type: "SHOW_WARNING", site, allowContinue });
}

async function logFocusEvent(type, site) {
  await dbAdd("focus_events", { type, site, timestamp: new Date().toISOString() });
}

function sendToTab(tabId, message) {
  if (!tabId) return;
  chrome.tabs.sendMessage(tabId, message).catch(e => {
    console.log("[FocusTracker] sendMessage skipped (tab not ready):", e?.message);
  });
}

// ─── Chrome Event Listeners ───────────────────────────────────────────────────

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  if (currentSession) currentSession.tabSwitches = (currentSession.tabSwitches || 0) + 1;
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab?.url) await startNewSession(tab.url);
    // Note: content.js proactively checks focus state on load,
    // so we don't need to sendMessage here for initial page check.
  } catch {}
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete" || !tab.active) return;
  if (!tab?.url) return;
  await startNewSession(tab.url);
  // Check focus mode — small delay to let content script initialize
  setTimeout(async () => {
    await checkFocusMode(getHostname(tab.url), tabId);
  }, 500);
});

chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    await endCurrentSession();
  } else {
    try {
      const [tab] = await chrome.tabs.query({ active: true, windowId });
      if (tab?.url) await startNewSession(tab.url);
    } catch {}
  }
});

// Periodic flush — keeps sessions in DB even during very long single-site sessions
chrome.alarms.create("flush", { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== "flush" || !currentSession) return;
  console.log("[FocusTracker] Alarm flush for:", currentSession.site);
  const url = currentSession.url;
  await endCurrentSession();
  await startNewSession(url);
});

// ─── Idle Detection ───────────────────────────────────────────────────────────
(async () => {
  // Use a configurable idle timeout (default 5 minutes / 300s)
  const idleTimeout = await getSetting("idleTimeout", 300);
  chrome.idle.setDetectionInterval(idleTimeout);
})();

chrome.idle.onStateChanged.addListener(async (newState) => {
  if (newState === "idle" || newState === "locked") {
    console.log("[FocusTracker] System idle/locked, ending session to prevent metric skew");
    await logFocusEvent("system_idle", "");
    await endCurrentSession();
  } else if (newState === "active") {
    // Resume session on current tab if we became active again
    try {
      const tabs = await chrome.tabs.query({ active: true, windowId: chrome.windows.WINDOW_ID_CURRENT });
      if (tabs[0]?.url) await startNewSession(tabs[0].url);
    } catch {}
  }
});

// ─── Message Handler ──────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      switch (msg.type) {

        case "INTERACTION":
          if (currentSession) currentSession.interactions = (currentSession.interactions || 0) + 1;
          sendResponse({ ok: true });
          break;

        case "CONTINUE":
          await logFocusEvent("continue_clicked", msg.site || "");
          sendResponse({ ok: true });
          break;

        case "END_SESSION":
          await setSetting("focusEnabled", false);
          await setSetting("sessionStart", null);
          await logFocusEvent("session_ended_user", msg.site || "");
          await endCurrentSession();
          // Broadcast to all tabs
          const tabs = await chrome.tabs.query({});
          tabs.forEach(t => t.id && chrome.tabs.sendMessage(t.id, { type: "FOCUS_ENDED", reason: "user" }).catch(() => {}));
          sendResponse({ ok: true });
          break;

        case "START_FOCUS":
          await setSetting("focusEnabled", true);
          await setSetting("sessionStart", new Date().toISOString());
          await logFocusEvent("session_started", "");
          console.log("[FocusTracker] Focus session started");
          sendResponse({ ok: true });
          break;

        case "GET_STATUS": {
          const [settings, cs] = await Promise.all([
            Promise.all([
              getSetting("focusEnabled",    false),
              getSetting("blockedSites",    []),
              getSetting("sensitivity",     "medium"),
              getSetting("sessionDuration", 25),
              getSetting("allowContinue",   true),
              getSetting("sessionStart",    null),
            ]).then(([focusEnabled, blockedSites, sensitivity, sessionDuration, allowContinue, sessionStart]) =>
              ({ focusEnabled, blockedSites, sensitivity, sessionDuration, allowContinue, sessionStart })
            ),
            Promise.resolve(currentSession
              ? { site: currentSession.site, elapsed: Math.round((Date.now() - currentSession.startTime) / 1000) }
              : null
            ),
          ]);
          sendResponse({ settings, currentSession: cs });
          break;
        }

        case "LABEL_SITE":
          await dbPut("user_labels", { site: msg.site, label: msg.label, updatedAt: new Date().toISOString() });
          sendResponse({ ok: true });
          break;

        case "WARNING_SHOWN_LOG":
          await logFocusEvent("warning_shown", msg.site || "");
          sendResponse({ ok: true });
          break;

        case "SITE_BLOCKED_LOG":
          await logFocusEvent("site_blocked", msg.site || "");
          sendResponse({ ok: true });
          break;

        case "BYPASS_ATTEMPT_LOG":
          await logFocusEvent("bypass_attempt", msg.site || "");
          console.warn(`[FocusTracker] Bypass attempt logged for ${msg.site}. Reason: ${msg.reason}`);
          sendResponse({ ok: true });
          break;

        case "INTERVENTION_SHOWN":
          await logFocusEvent("intervention_shown", msg.site || "");
          console.log(`[FocusTracker] Intervention shown for ${msg.label || msg.site}`);
          sendResponse({ ok: true });
          break;

        case "INTERVENTION_CONTINUE":
          await logFocusEvent("intervention_continue", msg.site || "");
          console.log(`[FocusTracker] User continued past intervention on ${msg.site}`);
          sendResponse({ ok: true });
          break;

        default:
          sendResponse({ error: "Unknown message type" });
      }
    } catch (e) {
      console.error("[FocusTracker] Message handler error:", e);
      sendResponse({ error: e.message });
    }
  })();
  return true;
});

// ─── Init ─────────────────────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(() => {
  console.log("[FocusTracker] Extension installed / updated");
  // Only set defaults if they haven't been set yet (e.g. first install).
  // Never overwrite existing settings — the dashboard owns them.
  chrome.storage.local.get(["focusEnabled"], (result) => {
    if (result.focusEnabled === undefined) {
      chrome.storage.local.set({
        focusEnabled:    false,
        blockedSites:    [],
        productiveDomains: [],
        sensitivity:     "medium",
        sessionDuration: 25,
        idleTimeout:     300,
        allowContinue:   true,
        sessionStart:    null,
      });
      console.log("[FocusTracker] Default settings applied (first install)");
    }
  });
});

console.log("[FocusTracker] Service worker started");

// ─── [ADDED] Real-time tab navigation intervention ────────────────────────────
//
// Backup guarantee: even if content.js fires too early (before DOM is ready),
// background.js independently pushes SHOW_INTERVENTION via chrome.tabs.sendMessage
// the moment the tab reaches "complete" state on a distracting URL.
//
// Rate-limit: once per tab per URL change (stored in service worker memory).
// Does NOT spam — sessionStorage on the content side also gates repeat fires.
// ─────────────────────────────────────────────────────────────────────────────

const DISTRACTING_HOSTS = new Set([
  "youtube.com", "youtu.be", "twitter.com", "x.com",
  "instagram.com", "facebook.com", "reddit.com", "tiktok.com",
  "snapchat.com", "pinterest.com", "twitch.tv", "netflix.com",
  "primevideo.com", "9gag.com", "tumblr.com", "discord.com",
  "whatsapp.com", "telegram.org", "amazon.com", "flipkart.com",
  "quora.com", "buzzfeed.com", "hotstar.com", "disneyplus.com",
  "hbomax.com", "hulu.com", "peacocktv.com", "espn.com",
  "linkedin.com",
]);

// tabId → last URL we pushed an intervention for (prevents repeat on same page)
const _tabLastIntervened = new Map();

function _getDistractionHost(urlStr) {
  try {
    const host = new URL(urlStr).hostname.replace(/^www\./, "");
    for (const d of DISTRACTING_HOSTS) {
      if (host === d || host.endsWith("." + d)) return d;
    }
  } catch (_) {}
  return null;
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Fire once the tab has fully loaded its URL
  if (changeInfo.status !== "complete" || !tab.url) return;

  const host = _getDistractionHost(tab.url);
  if (!host) {
    // Navigated away — reset so next visit fires fresh
    _tabLastIntervened.delete(tabId);
    return;
  }

  // Already intervened for this exact URL in this tab — skip
  if (_tabLastIntervened.get(tabId) === tab.url) return;
  _tabLastIntervened.set(tabId, tab.url);

  chrome.storage.local.get(['productiveDomains', 'blockedSites'], (result) => {

    const productiveDomains = Array.isArray(result.productiveDomains) ? result.productiveDomains : [];
    const blockedSites      = Array.isArray(result.blockedSites) ? result.blockedSites : [];

    let urlObj;
    try {
      urlObj = new URL(tab.url);
    } catch (_) {
      return;
    }

    const currentHost = urlObj.hostname.replace(/^www\./, '').toLowerCase();
    const currentPath = (currentHost + urlObj.pathname.replace(/\/$/, '')).toLowerCase();

    const matchesEntry = (entry) => {
      if (!entry) return false;
      const normalized = entry.toLowerCase();
      if (normalized.includes('/')) {
        return currentPath === normalized || currentPath.startsWith(normalized + '/');
      }
      return currentHost === normalized || currentHost.endsWith('.' + normalized);
    };

    const isBlocked = blockedSites.some(matchesEntry);
    const isProductive = productiveDomains.some(matchesEntry);

    // Precedence: blocked wins over productive and should be treated as distracting.
    if (isProductive && !isBlocked) return;
    if (!isBlocked && !host) return;

    // Push SHOW_INTERVENTION to content.js — it plays sound + shows popup.
    // Content.js sessionStorage cooldown prevents double-fire if it already self-triggered.
    const targetSite = isBlocked ? currentHost : host;
    chrome.tabs.sendMessage(tabId, { type: "SHOW_INTERVENTION", site: targetSite }).catch(() => {
      // Tab may not have content script (chrome:// pages etc.) — ignore silently
    });
  });
});

chrome.tabs.onRemoved.addListener((tabId) => {
  _tabLastIntervened.delete(tabId);
});
